#!/bin/bash
# scp ~/ldh_test/fw_payload.bin axu15eg:~
sshpass -p root scp ~/ldh_test/fw_payload.bin axu15eg:~
