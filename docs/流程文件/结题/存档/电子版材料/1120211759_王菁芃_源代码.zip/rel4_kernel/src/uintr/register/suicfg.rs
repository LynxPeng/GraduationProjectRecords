//! suicfg register

write_csr_as_usize!(0x1B2);
read_csr_as_usize!(0x1B2);